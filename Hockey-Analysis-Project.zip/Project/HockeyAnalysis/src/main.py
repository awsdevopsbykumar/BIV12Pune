from pyspark.sql import Window
from pyspark.sql.functions import rank, col, sum

from src.models.dimension_models.club_dim import create_club_dimension
from src.models.dimension_models.country_dim import create_country_dimension
from src.models.dimension_models.league_dim import create_league_dimension
from src.models.dimension_models.match_dim import create_match_dimension
from src.models.dimension_models.player_dim import create_player_dimension
from src.models.dimension_models.time_dim import create_time_dimension
from src.models.fact_models.player_fact import create_player_stats_fact_table
from src.models.fact_models.team_fact import create_team_stats_fact_table

from src.util.csv_utils import load_csv, save_csv
from src.util.spark_utils import create_spark_session, end_spark_session
import config


def main():
    spark = create_spark_session(config.APP_NAME, config.MASTER)

    hockey_player_frame = load_csv(spark, config.RAW_DIR_PATH + "/Hockey_Src1.csv")
    hockey_team_dataframe = load_csv(spark, config.RAW_DIR_PATH + "/Hockey_Src2.csv")
    date_dataframe = load_csv(spark, config.RAW_DIR_PATH + "/DIM.Date.Table.csv")

    league_dimension_table = create_league_dimension(hockey_team_dataframe)
    club_dimension_table = create_club_dimension(hockey_team_dataframe, league_dimension_table)
    country_dimension_table = create_country_dimension(hockey_team_dataframe)
    match_dimension_table = create_match_dimension(hockey_team_dataframe)
    player_dimension_table = create_player_dimension(hockey_player_frame, club_dimension_table, country_dimension_table)
    time_dimension_table = create_time_dimension(date_dataframe)

    # Create fact tables
    player_fact_df = create_player_stats_fact_table(hockey_player_frame,
                                                    time_dimension_table=time_dimension_table,
                                                    match_type_dimension_table=match_dimension_table,
                                                    club_dimension_table=club_dimension_table,
                                                    country_dimension_table=country_dimension_table,
                                                    player_dimension_table=player_dimension_table)

    team_fact_df = create_team_stats_fact_table(hockey_team_dataframe,
                                                time_dimension_table=time_dimension_table,
                                                match_type_dimension_table=match_dimension_table,
                                                league_dimension_table=league_dimension_table,
                                                club_dimension_table=club_dimension_table,
                                                country_dimension_table=country_dimension_table)

    # Using aliases for better clarity
    player_fact_df = player_fact_df.alias("player_fact")
    team_fact_df = team_fact_df.alias("team_fact")
    country_df = country_dimension_table.alias("country")
    club_df = club_dimension_table.alias("club")
    player_dim_df = player_dimension_table.alias("player_dim")
    match_type_df = match_dimension_table.alias("match")
    league_df = league_dimension_table.alias("league")
    time_df = time_dimension_table.alias("time")

    player_df = player_dimension_table \
        .select("player_id", "player_name") \
        .distinct() \
        .alias("player")

    ##1
    player_club_country_df = player_fact_df \
        .join(country_df,
              on=player_fact_df.country_id == country_df.country_id,
              how='left') \
        .join(club_df,
              on=player_fact_df.club_id == club_df.club_id,
              how='left') \
        .join(player_df,
              on=player_fact_df.player_id == player_df.player_id,
              how='inner') \
        .select(
            'player_fact.player_id',
            'player.player_name',
            'country.country_id',
            'country.country_name',
            'club.club_id',
            'club.club_name'
        ) \
        .distinct() \
        .orderBy(player_fact_df['player_id'])

    # Display the resulting DataFrame
    save_csv(player_club_country_df, config.OUTPUT_DIR_PATH + '/answer_q1.csv')
    print(player_club_country_df.show())

    ##2
    # Joining player statistics with player dimension and match type dimension
    player_stats_join_player_dimension = player_fact_df \
        .join(player_df,  # Joining with the player dimension
              on=player_fact_df.player_id == player_df.player_id,
              how='inner') \
        .join(match_type_df,  # Joining with the match type dimension
              on=player_fact_df.match_type_id == match_type_df.match_type_id,
              how='inner') \
        .filter(col('match.match_name') == 'International') \
        .select("player.player_id",  # Selecting relevant columns
                "player.player_name",
                player_fact_df['appearances'])

    # Grouping by player ID and name, and aggregating total appearances
    player_appearances_dataframe = player_stats_join_player_dimension \
        .groupBy("Player_Id", "Player_Name") \
        .agg(sum("appearances").alias("total_appearances"))

    # Ranking players by total appearances and filtering for the top player
    max_player_appearances = player_appearances_dataframe \
        .withColumn("appearance_rank",  # Adding a ranking column based on total appearances
                    rank().over(Window.orderBy("total_appearances"))) \
        .select("player_id", "player_name", "total_appearances") \
        .filter(col("appearance_rank") == 1)  # Filtering to get only the top-ranked player

    # Displaying results of all player appearances
    save_csv(max_player_appearances, config.OUTPUT_DIR_PATH + '/answer_q2.csv')
    print(max_player_appearances.show())

    ##3
    # Grouping and Aggregation
    goals_df = player_fact_df \
        .join(time_df,
              on=time_df.time_id == player_fact_df.time_id,
              how='inner') \
        .where(col('year') == '2010') \
        .groupBy('player_id') \
        .agg(sum('goals_scored').alias('goals_scored'))

    goals_df = goals_df \
        .join(player_df,  # Joining with the player dimension
              on=player_df.player_id == goals_df.player_id,
              how='inner') \
        .select('player.player_id', 'player.player_name', 'goals_scored')

    max_goals_df = goals_df \
        .withColumn('goal_rank', rank().over(Window.orderBy(col('goals_scored').desc()))) \
        .select('player_id', 'player_name', 'goals_scored') \
        .orderBy(col('goals_scored').desc(), col('player_name').asc()) \
        .filter(col('goal_rank') <= 10)

    save_csv(max_goals_df, config.OUTPUT_DIR_PATH + '/answer_q3.csv')
    print(max_goals_df.show())

    ##4

    # Grouping and Aggregation
    red_card_df = player_fact_df \
        .groupBy('player_id') \
        .agg(sum('red_card').alias('red_cards'))

    red_card_df = red_card_df \
        .join(player_df,  # Joining with the player dimension
              on=player_df.player_id == red_card_df.player_id,
              how='inner') \
        .select('player.player_id', 'player.player_name', 'red_cards')

    max_red_cards_df = red_card_df \
        .withColumn('card_rank', rank().over(Window.orderBy(col('red_cards').desc()))) \
        .select('player_id', 'player_name', 'red_cards') \
        .orderBy(col('red_cards').desc(), col('player_name').asc()) \
        .filter(col('card_rank') <= 5)

    save_csv(max_red_cards_df, config.OUTPUT_DIR_PATH + '/answer_q4.csv')
    print(max_red_cards_df.show())

    ## 5
    club_wins_df = team_fact_df \
        .groupBy('club_id') \
        .agg(sum('wins').alias('wins'))

    club_wins_df = club_wins_df \
        .join(club_df,
              on=club_df.club_id == club_df.club_id,
              how='inner') \
        .filter(col('club_name') != 'NA') \
        .select(club_wins_df["club_id"], "club_name", "wins")

    max_club_wins_df = club_wins_df \
        .withColumn('win_rank', rank().over(Window.partitionBy().orderBy(col('wins').desc()))) \
        .select('club_id', 'club_name', 'wins') \
        .orderBy(col("wins").desc(), col("club_name").asc()) \
        .filter(col('win_rank') <= 5)

    save_csv(max_club_wins_df, config.OUTPUT_DIR_PATH + '/answer_q5.csv')
    print(max_club_wins_df.show())

    end_spark_session(spark)


if __name__ == "__main__":
    main()
