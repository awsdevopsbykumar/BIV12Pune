from pyspark.sql import Window
from pyspark.sql.functions import col, rank

from src import config
from src.util.csv_utils import save_csv


def create_time_dimension(date_dataframe):
    """Create the time dimension table."""
    extracted_time_table = date_dataframe \
        .select("fb_year", "quarter", "fb_month", "month_name") \
        .distinct()

    time_dimension_table = extracted_time_table \
        .withColumn("time_id", rank().over(Window.orderBy("fb_year", "quarter", "fb_month"))) \
        .withColumnRenamed("fb_year", "year") \
        .withColumnRenamed("quarter", "quarter") \
        .withColumnRenamed("month_name", "month") \
        .withColumnRenamed("fb_month", "month_num") \
        .select("time_id", "year", "quarter", "month", "month_num")

    save_csv(time_dimension_table, config.PROCESSED_DIR_PATH + "/dimension/time_dimension.csv")
    return time_dimension_table
