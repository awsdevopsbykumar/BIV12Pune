from pyspark.sql import Window
from pyspark.sql.functions import col, rank
from src.util.csv_utils import save_csv
from src import config


def create_club_dimension(src_dataframe, league_dimension_table):
    """Create the club dimension table."""
    extracted_club_table = src_dataframe \
        .select(col("League_Name"), col("Club_Name"), col("Manager"), col("Owner")) \
        .distinct() \
        .filter(col("Club_Name") != 'NA')

    # Rename columns to lowercase with underscores
    extracted_club_table = extracted_club_table \
        .withColumnRenamed("League_Name", "league_name") \
        .withColumnRenamed("Club_Name", "club_name") \
        .withColumnRenamed("Manager", "manager") \
        .withColumnRenamed("Owner", "owner") \
        .withColumn("club_id", rank().over(Window.orderBy(col("club_name")))) \
        .select(col("club_id"), col("league_name"), col("club_name"), col("manager"), col("owner"))

    club_dimension_table = extracted_club_table.join(league_dimension_table,
                                                     on=extracted_club_table.league_name == league_dimension_table.league_name,
                                                     how='outer') \
        .select(col("club_id"), col("league_id"), col("club_name"), col("manager"), col("owner")) \
        .orderBy(col("club_id"))

    save_csv(club_dimension_table, config.PROCESSED_DIR_PATH + '/dimension/club_dimension.csv')
    return club_dimension_table
