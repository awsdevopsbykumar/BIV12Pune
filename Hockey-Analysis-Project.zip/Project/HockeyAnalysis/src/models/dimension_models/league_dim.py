from pyspark.sql import Window
from pyspark.sql.functions import col, rank

from src import config
from src.util.csv_utils import save_csv


def create_league_dimension(src_dataframe):
    """Create the league dimension table."""
    extracted_league_table = src_dataframe.select(col("League_Name")) \
        .distinct() \
        .filter(col("League_Name") != 'NA') \
        .orderBy(col("League_Name"))

    league_dimension_table = extracted_league_table \
        .withColumnRenamed("League_Name", "league_name") \
        .withColumn("league_id", rank().over(Window.orderBy("league_name"))) \
        .select("league_id", "league_name")

    save_csv(league_dimension_table, config.PROCESSED_DIR_PATH + "/dimension/league_dimension.csv")
    return league_dimension_table
