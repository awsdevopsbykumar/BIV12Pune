from pyspark.sql import Window
from pyspark.sql.functions import col, rank

from src import config
from src.util.csv_utils import save_csv


def create_player_dimension(src_dataframe, club_dimension_table, country_dimension_table):
    """Create the player dimension table."""
    extracted_player_table = src_dataframe \
        .select("Player Name", "Club Name", "country Name", "Position", "Jersey_No", col("`D. O. B.`"), "Nationality") \
        .distinct()

    extracted_player_table = extracted_player_table \
        .withColumnRenamed("Player Name", "player_name") \
        .withColumnRenamed("Club Name", "club_name") \
        .withColumnRenamed("country Name", "country_name") \
        .withColumn("player_id", rank().over(Window.orderBy(col("player_name")))) \
        .withColumn("dob", col("`D. O. B.`")) \
        .withColumnRenamed("Nationality", "nationality") \
        .select("player_id", "player_name", "club_name", "country_name", "Position", "Jersey_No", "dob", "nationality")

    player_dimension_table = extracted_player_table \
        .join(club_dimension_table,
              on=extracted_player_table.club_name == club_dimension_table.club_name,
              how='left') \
        .join(country_dimension_table,
              on=extracted_player_table.country_name == country_dimension_table.country_name,
              how='left') \
        .select("player_id", "player_name", "club_id", "country_id", "Position", "Jersey_No", "dob", "nationality") \
        .orderBy("player_id")

    save_csv(player_dimension_table, config.PROCESSED_DIR_PATH + "/dimension/player_dimension.csv")
    return player_dimension_table
