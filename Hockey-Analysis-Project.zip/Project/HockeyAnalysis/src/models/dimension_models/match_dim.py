from pyspark.sql import Window
from pyspark.sql.functions import col, rank

from src import config
from src.util.csv_utils import save_csv


def create_match_dimension(src_dataframe):
    """Create the match type dimension table."""
    extracted_match_table = src_dataframe \
        .select("Match_Name") \
        .distinct()

    match_type_dimension_table = extracted_match_table \
        .withColumnRenamed("Match_Name", "match_name") \
        .withColumn("match_type_id", rank().over(Window.orderBy(col("match_name")))) \
        .select("match_type_id", "match_name")

    save_csv(match_type_dimension_table, config.PROCESSED_DIR_PATH + "/dimension/match_dimension.csv")
    return match_type_dimension_table
