from pyspark.sql import Window
from pyspark.sql.functions import col, rank
from src.util.csv_utils import save_csv
from src import config


def create_country_dimension(src_dataframe):
    """Create the country dimension table."""
    extracted_country_table = src_dataframe \
        .select(col("Country Name"), col("Coach")) \
        .distinct() \
        .filter(col("Country Name") != 'NA')

    country_dimension_table = extracted_country_table \
        .withColumnRenamed("Country Name", "country_name") \
        .withColumn("country_id", rank().over(Window.orderBy(col("country_name")))) \
        .select("country_id", "country_name", "Coach") \
        .withColumnRenamed("Coach", "coach")  # Renaming Coach to lowercase

    save_csv(country_dimension_table, config.PROCESSED_DIR_PATH + "/dimension/country_dimension.csv")
    return country_dimension_table
