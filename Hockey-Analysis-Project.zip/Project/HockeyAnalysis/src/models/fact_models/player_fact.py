from pyspark.sql.functions import col, monotonically_increasing_id

from src import config
from src.util.csv_utils import save_csv


def create_player_stats_fact_table(player_src_dataframe, **kwargs):
    """create the player stats fact table."""

    time_dimension_table = kwargs.get('time_dimension_table')
    match_type_dimension_table = kwargs.get('match_type_dimension_table')
    club_dimension_table = kwargs.get('club_dimension_table')
    country_dimension_table = kwargs.get('country_dimension_table')
    player_dimension_table = kwargs.get('player_dimension_table')

    player_df = player_dimension_table \
        .select("Player_Id", "Player_Name") \
        .distinct() \
        .alias("player")

    extracted_hockey_player_table = player_src_dataframe.alias("hockey") \
        .join(time_dimension_table.alias("time"),
              (col("hockey.month") == col("time.month")) &
              (col("hockey.year") == col("time.year")),
              how='inner') \
        .join(match_type_dimension_table.alias("match"),
              col("hockey.match") == col("match.match_name"),
              how='inner') \
        .join(player_df,
              col("hockey.player name") == col("player.player_name"),
              how='inner') \
        .join(club_dimension_table.alias("club"),
              col("hockey.club name") == col("club.club_name"),
              how='left') \
        .join(country_dimension_table.alias("country"),
              col("hockey.country name") == col("country.country_name"),
              how='left') \
        .select("time.time_Id", "match.match_type_id", "player.player_id", "club.club_id", "country.country_id",
                "appearances", "goals scored", "goals assist", "total shots", "shots on target", "fouls made",
                "fouls suffered", "yellow card", "red card", "goals saved", "goals conceded(stopped)",
                "total penalty", "successful penalty", "salary") \
        .orderBy("player_id")

    player_stats_fact_table = extracted_hockey_player_table \
        .withColumn("fact_id", monotonically_increasing_id() + 1) \
        .withColumnRenamed("goals scored", "goals_scored") \
        .withColumnRenamed("goals assist", "goals_assist") \
        .withColumnRenamed("total shots", "total_shots") \
        .withColumnRenamed("shots on target", "shots_on_target") \
        .withColumnRenamed("fouls made", "fouls_made") \
        .withColumnRenamed("fouls suffered", "fouls_suffered") \
        .withColumnRenamed("yellow card", "yellow_card") \
        .withColumnRenamed("red card", "red_card") \
        .withColumnRenamed("goals saved", "goals_saved") \
        .withColumnRenamed("goals conceded(stopped)", "goals_conceded") \
        .withColumnRenamed("total penalty", "total_penalty") \
        .withColumnRenamed("successful penalty", "successful_penalty") \
        .select("fact_id", "time_id", "match_type_id", "player_id", "club_id", "country_id",
                "appearances", "goals_scored", "goals_assist", "total_shots", "shots_on_target",
                "fouls_made", "fouls_suffered", "yellow_card", "red_card", "goals_saved",
                "goals_conceded", "total_penalty", "successful_penalty", "salary")

    save_csv(player_stats_fact_table, config.PROCESSED_DIR_PATH + "/fact/player_fact.csv")
    return player_stats_fact_table
