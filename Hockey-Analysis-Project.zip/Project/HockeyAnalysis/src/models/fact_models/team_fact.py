from pyspark.sql import Window
from pyspark.sql.functions import monotonically_increasing_id, row_number

from src import config
from src.util.csv_utils import save_csv


def create_team_stats_fact_table(team_src_dataframe,
                                 **kwargs):
    """Create the team stats fact table."""

    time_dimension_table = kwargs.get('time_dimension_table')
    match_type_dimension_table = kwargs.get('match_type_dimension_table')
    league_dimension_table = kwargs.get('league_dimension_table')
    club_dimension_table = kwargs.get('club_dimension_table')
    country_dimension_table = kwargs.get('country_dimension_table')

    modified_hockey_team_dataframe = team_src_dataframe \
        .withColumn("month", row_number() \
                    .over(Window \
                          .partitionBy("Year", "Match_Name", "League_Name", "Club_Name", "Coach",
                                       "Country Name", "Manager", "Owner") \
                          .orderBy("Year", "Match_Name", "League_Name", "Club_Name", "Coach",
                                   "Country Name", "Manager", "Owner"))) \
        .orderBy('Club_Name', 'Year', 'Month')

    hockey_team_df = modified_hockey_team_dataframe.alias("hockey_team")

    extracted_hockey_team_table = hockey_team_df \
        .join(time_dimension_table.alias("time"),
              (hockey_team_df['Year'] == time_dimension_table.year) &
              (hockey_team_df['Month'] == time_dimension_table.month_num),
              how='inner') \
        .join(match_type_dimension_table.alias("match"),
              hockey_team_df['Match_Name'] == match_type_dimension_table.match_name,
              how='inner') \
        .join(league_dimension_table.alias("league"),
              hockey_team_df['League_Name'] == league_dimension_table.league_name,
              how='inner') \
        .join(club_dimension_table.alias("club"),
              hockey_team_df['Club_Name'] == club_dimension_table.club_name,
              how='left') \
        .join(country_dimension_table.alias("country"),
              hockey_team_df['country name'] == country_dimension_table.country_name,
              how='left') \
        .withColumn("fact_id", monotonically_increasing_id() + 1) \
        .select("fact_id",
                "time.time_id",
                "match.match_type_id",
                "league.league_id",
                "club.club_id",
                "country.country_id",
                "appearances", "wins", "losts", "drawn", "clean sheets", "Net Worth")

    team_stats_fact_table = extracted_hockey_team_table \
        .withColumnRenamed("clean sheets", "clean_sheets") \
        .withColumnRenamed("Net Worth", "net_worth") \
        .select("fact_id", "time_id", "match_type_id", "league_id", "club_id", "country_id",
                "appearances", "wins", "losts", "drawn", "clean_sheets", "net_worth")

    save_csv(team_stats_fact_table, config.PROCESSED_DIR_PATH + "/fact/team_fact.csv")
    return team_stats_fact_table
