import pandas as pd


def load_csv(spark, file_path, header="true", infer_schema="true"):
    """Load a CSV file into a DataFrame."""
    try:
        df = spark.read.format("csv") \
            .option("header", header) \
            .option("inferSchema", infer_schema) \
            .load(file_path)
        return df
    except Exception as e:
        print(f"Error loading CSV file from {file_path}: {e}")
        return None  # Return None or handle as appropriate


def save_csv(dataframe, save_path):
    """Save a DataFrame as a CSV file."""
    try:
        pandas_df = dataframe.toPandas()
        pandas_df = pandas_df.fillna('NULL')
        pandas_df.to_csv(save_path, index=False)
        print(f"Successfully saved DataFrame to {save_path}")
    except Exception as e:
        print(f"Error saving DataFrame to {save_path}: {e}")


