from pyspark.sql import SparkSession


def create_spark_session(app_name, master):
    """Create and return a Spark session."""
    spark = SparkSession.builder \
        .appName(app_name) \
        .master(master) \
        .getOrCreate()
    return spark


def end_spark_session(spark):
    spark.stop()

