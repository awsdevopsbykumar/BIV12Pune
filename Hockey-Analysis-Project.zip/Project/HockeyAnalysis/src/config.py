import os

RAW_DIR_PATH = os.path.join("src", "data", "raw")
PROCESSED_DIR_PATH = os.path.join("src", "data", "processed")
OUTPUT_DIR_PATH = os.path.join("src", "output")


APP_NAME = 'Hockey Analysis'
MASTER = 'local[*]'

