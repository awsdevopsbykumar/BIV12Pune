## Installation
 
1. **Install Python 3.x:**
   - Download and install Python 3.x from the official website: [Python Downloads](https://www.python.org/downloads/).
   - Make sure to check the box that says "Add Python to PATH" during installation.
 
2. **Install Apache Spark 3.x:**
   - Download Spark 3.x from the official site: [Spark Downloads](https://spark.apache.org/downloads.html).
   - Follow the instructions on the website to set up Spark on your system.
 
3. **Install PySpark and other necessary packages:**
   - You can install PySpark and any other required packages using pip:
   ```bash
   pip install -r req.txt
   

## Directory Structure 
 
The project has the following directory structure:

project_root/ \
├── appLogs/ \
│   └── ─── sparkLogs.out \
├── notebooks/ \
│   └── ─── Notebook.ipynb \
├── README.md \
├── req.txt \
├── resources/ \
│   └── ─── log4j.properties \
└── src/ \
    ├── ─── config.py \
    ├── data/ \
    │   ├── ─── processed/ \
    │   │   ├── ─── ─── dimension/ \
    │   │   └── ─── ─── fact/ \
    │   └── ─── raw/ \
    │       ├── ─── ─── DIM.Date.Table.csv \
    │       ├── ─── ─── Hockey_Src1.csv \
    │       └── ─── ─── Hockey_Src2.csv \
    ├── ─── main.py \
    ├── models/ \
    │   ├── ─── dimension_models/ \
    │   ├── ─── fact_models/ \
    ├── ─── output/ \
    ├── util/ \
    │   ├── ─── csv_utils.py \
    │   ├── ─── logger.py \
    │   ├── ─── spark_utils.py \
    ├── ─── __init__.py


## Usage
 
To run the project and perform data processing and analysis, follow these steps:
 
1. **Prepare Your Environment**: Ensure that you have installed all necessary dependencies as outlined in the [Installation](#installation) section.
 
2. **Run the Main Script**:
   - Navigate to the project directory if you haven't already:
   ```bash
   cd repo
   spark-submit src/main.py
   

## License
 
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
 
### Summary of the MIT License
 
The MIT License is a permissive free software license that allows for the following:
 
- You can use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the software.
- You can include the software in proprietary projects.
- The software is provided "as is," without warranty of any kind.
 
For more detailed information, please refer to the full text of the MIT License in the LICENSE file.
