# main.py

#importing libraries
import os
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import Window



def load_data(spark):
    """
    Load the dimension and fact tables from CSV files.

    Args:
        sparks (SparkSession): The Spark session.

    Returns:
        DataFrame: DataFrames for college, company, survey, time, and fact tables.
    """
    college_dim_df = spark.read.csv('./Scripts/dimension_table/college_dimension.csv', header=True, inferSchema=True)
    company_dim_df = spark.read.csv('./Scripts/dimension_table/company_dimension.csv', header=True, inferSchema=True)
    survey_dim_df = spark.read.csv('./Scripts/dimension_table/survey_dimension.csv', header=True, inferSchema=True)
    time_dim_df = spark.read.csv('./Scripts/dimension_table/time_dimension.csv', header=True, inferSchema=True)
    fact_college_df = spark.read.csv('./Scripts/fact_table/fact_college_details.csv', header=True, inferSchema=True)
    fact_survey_df = spark.read.csv('./Scripts/fact_table/fact_survey_details.csv', header=True, inferSchema=True)

    return college_dim_df, company_dim_df, survey_dim_df, time_dim_df, fact_college_df, fact_survey_df

#Generate year-wise top 3 college ranking

def yearwise_top3_college_ranking(spark, fact_college_details, college_dim, time_dim):
    # Join fact table with college and time dimension to get College Name and Year
    joined_df = fact_college_details.join(college_dim, "College_ID").join(time_dim, "Time_ID")

    # Group by Year and College to get the average number of students selected per year
    avg_students_per_college = joined_df.groupBy("Year", "College_Name").agg(
        F.avg("Student_Selected").alias("Average_Students_Selected")
    )

    # Create a window partitioned by year and ordered by the average number of students selected in descending order
    window = Window.partitionBy("Year").orderBy(F.desc("Average_Students_Selected"))

    # Add a ranking column
    ranked_colleges = avg_students_per_college.withColumn("Rank", F.rank().over(window))

    # Filter to keep only the top 3 colleges for each year
    top_3_colleges = ranked_colleges.filter(F.col("Rank") <= 3)

    # Select Year, College Name, and Rank (remove Average Students Selected for a cleaner view)
    final_result = top_3_colleges.select("Year", "College_Name", "Rank")

    return final_result

# Function to calculate year-wise, college-wise percentage selection
def yearwise_college_percentage_selection(spark, fact_college_details, college_dim, company_dim, time_dim):
    # Step 1: Join fact table with college, company, and time dimensions
    joined_df = fact_college_details.join(college_dim, "College_ID") \
        .join(company_dim, "Company_ID") \
        .join(time_dim, "Time_ID")

    # Step 2: Calculate the total number of students selected per college per year
    total_students_per_college = joined_df.groupBy("Year", "College_Name").agg(
        F.sum("Student_Selected").alias("Total_Students_Selected")
    )

    # Step 3: Calculate the number of students selected by each company in each college per year
    students_per_company = joined_df.groupBy("Year", "College_Name", "Company_Name") \
        .agg(F.sum("Student_Selected").alias("Company_Students_Selected"))

    # Step 4: Join the total students data with the company-specific data
    percentage_selection = students_per_company.join(
        total_students_per_college,
        ["Year", "College_Name"]
    )

    # Step 5: Calculate the percentage selection for each company
    percentage_selection = percentage_selection.withColumn(
        "Percentage_Selection",
        F.round((F.col("Company_Students_Selected") / F.col("Total_Students_Selected")), 4)
    )

    # Step 6: Select relevant columns for final output
    final_result = percentage_selection.select(
        "Year", "College_Name", "Company_Name", "Percentage_Selection"
    ).orderBy("Year", "College_Name")

    return final_result

#Function for yearwise-quarterwise-placement
def yearwise_quarterwise_placement(spark, fact_college_details, time_dim, college_dim):
    # Step 1: Join fact table with time dimension and college dimension
    joined_df = fact_college_details.join(time_dim, "Time_ID") \
        .join(college_dim, "College_ID")

    # Step 2: Calculate total students selected for each year, quarter, and college
    total_students_per_quarter = joined_df.groupBy("Year", "Quarter", "College_Name").agg(
        F.sum("Student_Selected").alias("Total_Students_Selected")
    )

    # Step 3: Select the relevant columns and sort by Year, Quarter, and College_Name
    final_result = total_students_per_quarter.select(
        "Year", "Quarter", "College_Name", "Total_Students_Selected"
    ).orderBy("Year", "Quarter", "Total_Students_Selected", ascending=[True, True, False])

    return final_result

#Function for total-students-per-company-with-package

def total_students_per_company_with_package(spark, fact_college_details, company_dim, time_dim):
    # Step 1: Join fact table with company and time dimensions to get company names and years
    joined_df = fact_college_details.join(company_dim, "Company_ID").join(time_dim, "Time_ID")

    # Step 2: Filter for the year 2012
    filtered_df = joined_df.filter(F.col("Year") == 2012)

    # Step 3: Group by Year, Company Name, and Package, and calculate the total students selected
    total_students = filtered_df.groupBy("Year", "Company_Name", "Package_In_Lakhs").agg(
        F.sum("Student_Selected").alias("Total_Students_Selected")
    )

    # Step 4: Select final output columns: Year, Company Name, Package, and Total Students Selected
    final_result = total_students.select("Year", "Company_Name", "Package_In_Lakhs", "Total_Students_Selected").orderBy(
        "Company_Name")

    return final_result


# Function to rank colleges ranking year-wise
def yearwise_college_ranking(spark, fact_college_details, college_dim, time_dim):
    # Step 1: Join fact table with college and time dimensions
    joined_df = fact_college_details.join(college_dim, "College_ID") \
        .join(time_dim, "Time_ID")

    # Step 2: Calculate total students selected per year and college
    total_students_per_college = joined_df.groupBy("Year", "College_Name").agg(
        F.sum("Student_Selected").alias("Total_Students_Selected")
    )

    # Step 3: Define a window specification to rank colleges by year
    window_spec = Window.partitionBy("Year").orderBy(F.desc("Total_Students_Selected"))

    # Step 4: Add a rank column based on the total number of students selected
    ranked_colleges = total_students_per_college.withColumn(
        "College_Rank", F.rank().over(window_spec)
    )

    # Step 5: Filter for a specific college (e.g., "DHIRUBHAI AMBANI INSTITUTE OF INFORMATION AND TECHNOLOGY")
    filtered_college = ranked_colleges.filter(
        F.col("College_Name") == "DHIRUBHAI AMBANI INSTITUTE OF INFORMATION AND TECHNOLOGY"
    )

    # Step 6: Select relevant columns and order by Year
    final_result = filtered_college.select(
        "Year", "College_Name", "College_Rank"
    ).orderBy("Year")

    return final_result



#start spark session
spark = SparkSession.builder.appName("SaveOutputsExample").getOrCreate()


if __name__ == "__main__":
    # Create Spark Session
    spark = SparkSession.builder \
        .appName("Generate Reports") \
        .master("local[*]") \
        .getOrCreate()

    # Load data
    college_dim, company_dim, survey_dim, time_dim, fact_college_details, fact_survey_details = load_data(spark)

    #QUERY 1 : Generate year-wise top 3 college ranking
    print("Generate year-wise top 3 college ranking: ")
    top_3_college_ranking_df = yearwise_top3_college_ranking(spark, fact_college_details, college_dim, time_dim)
    # Show the result in the desired format
    top_3_college_ranking_df.show(truncate=False)


    #QUERY 2: yearwise_college_percentage_selection:
    print("yearwise_college_percentage_selection: ")
    percentage_selection_df = yearwise_college_percentage_selection(spark, fact_college_details, college_dim, company_dim, time_dim )
    percentage_selection_df.show(truncate=False)


    #QUERY 3: yearwise_quarterwise_placement:
    print("yearwise_quarterwise_placement: ")
    quarterwise_placement_df = yearwise_quarterwise_placement(spark, fact_college_details, time_dim,college_dim)
    quarterwise_placement_df.show(truncate=False)


    #QUERY 4: total_students_per_company_with_package
    print("Total students per company with package: ")
    total_students_2012_df = total_students_per_company_with_package(spark, fact_college_details, company_dim, time_dim)
    total_students_2012_df.show(truncate=False)


    # QUERY 5: Generate year-wise ranking for the specific college
    print("Generate year-wise ranking for the specific college: ")
    college_ranking_df = yearwise_college_ranking(spark, fact_college_details, college_dim, time_dim)
    college_ranking_df.show(truncate=False)



    # Stop the Spark Session
    spark.stop()
