import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, row_number, date_format
from pyspark.sql.window import Window
from load_data import load_data  # Import the load_data function

# Create Spark session
spark = SparkSession.builder \
    .appName("Dimension Table Creation") \
    .getOrCreate()

# Load the data using the load_data function
df_company, df_college, df_date = load_data(spark)

# Create College Dimension Table
college_dim = df_college.select(
    col("College").alias("College_Name"),
    col("Location").alias("College_Location")
).distinct()

college_dim = college_dim.withColumn("College_ID", row_number().over(Window.orderBy("College_Name")))

# Reorder columns
college_dim = college_dim.select("College_ID", "College_Name", "College_Location")

# Show top 5 College Dimension Table
college_dim.show(5)

# Create Company Dimension Table
company_dim = df_company.select(
    col("Company_Name"),
    col("Head_Office_Location"),
    col("Country")
).distinct()

company_dim = company_dim.withColumn("Company_ID", row_number().over(Window.orderBy("Company_Name")))

# Reorder columns
company_dim = company_dim.select("Company_ID", "Company_Name", "Head_Office_Location", "Country")

# Show top 5 Company Dimension Table
company_dim.show(5)

# Create Survey Dimension Table
survey_dim = df_college.select("SURVEY_Name").distinct()
survey_dim = survey_dim.withColumn("Survey_ID", row_number().over(Window.orderBy("SURVEY_Name")))

# Reorder columns
survey_dim = survey_dim.select("Survey_ID", "SURVEY_Name")

# Show top 5 Survey Dimension Table
survey_dim.show(5)

# Create Time Dimension Table
time_dim = df_date.select(
    col("fb_year").alias("Year"),
    col("quarter").alias("Quarter"),
    col("month_num_overall").alias("Month"),
    col("month_name").alias("Month_Name"),
    col("day_of_week").alias("Day_of_Week"),
    col("full_date").alias("Date")
).distinct()

# Add Time_ID column
time_dim = time_dim.withColumn("Time_ID", row_number().over(Window.orderBy("Year", "Month", "Date")))


# Convert the Date format to dd-MMM-yyyy (e.g., 05-Jan-2012)
# Convert Date to string before writing to CSV
time_dim = time_dim.withColumn("Date", date_format(col("Date"), "dd-MM-yyyy"))


# Reorder columns to place Time_ID first
time_dim = time_dim.select("Time_ID", "Year", "Quarter", "Month", "Month_Name", "Day_of_Week", "Date")

# Show top 5 Time Dimension Table
time_dim.show(5)
time_dim.printSchema()

# Create dimension_table directory if it doesn't exist
output_dir = "dimension_table"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Save the dimension tables to CSV files in the dimension_table directory
college_dim.toPandas().to_csv(f"{output_dir}/college_dimension.csv", index=False)
company_dim.toPandas().to_csv(f"{output_dir}/company_dimension.csv", index=False)
survey_dim.toPandas().to_csv(f"{output_dir}/survey_dimension.csv", index=False)
time_dim.toPandas().to_csv(f"{output_dir}/time_dimension.csv", index=False)

# Stop the Spark session
spark.stop()
