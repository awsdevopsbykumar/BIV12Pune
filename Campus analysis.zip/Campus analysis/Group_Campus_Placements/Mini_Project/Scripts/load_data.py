from pyspark.sql import SparkSession
# from pyspark.sql import *

# Correcting the Spark session creation
spark = SparkSession.builder \
    .appName('loading_dataset') \
    .getOrCreate()

def load_data(spark):
    """
    Load the data from CSV files and return DataFrames.
    """
    df_company = spark.read.csv('../dataset/Campus_Source1_Company.csv', header=True, inferSchema=True)
    df_college = spark.read.csv('../dataset/Campus_Source2_College.csv', header=True, inferSchema=True)
    df_date = spark.read.csv('../dataset/DIM.Date.Table.csv', header=True, inferSchema=True)

    return df_company, df_college, df_date
def print_column_names(df, name):
    """
    Print the column names of the DataFrame.
    """
    print(f"Column names for {name}: {df.columns}")


#example main function to check if the data loaded or not.
if __name__ == "__main__":
    # Create Spark Session
    spark = SparkSession.builder \
        .appName("Load CSV Data") \
        .getOrCreate()

    # Call the function to load data
    df_company, df_college, df_date = load_data(spark)

    # Print column names for each DataFrame
    print_column_names(df_company, "Campus_Source1_Company")
    print_column_names(df_college, "Campus_Source2_College")
    print_column_names(df_date, "DIM.Date.Table")

    # Show a few rows from each DataFrame to verify
    print("Campus_Source1_Company Data:")
    df_company.show(5)
    df_company.printSchema()

    print("Campus_Source2_College Data:")
    df_college.show(5)
    df_college.printSchema()


    print("DIM.Date.Table Data:")
    df_date.show(5)

    # Stop the Spark Session
    spark.stop()