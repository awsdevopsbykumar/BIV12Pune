import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, row_number, to_date, lower, trim
from pyspark.sql.window import Window

# Create Spark session
spark = SparkSession.builder \
    .appName("Fact Table Creation") \
    .getOrCreate()


# Load source data for fact tables and dimension tables
def load_data():
    company_source_df = spark.read.csv('../dataset/Campus_Source1_Company.csv', header=True, inferSchema=True)
    college_source_df = spark.read.csv('../dataset/Campus_Source2_College.csv', header=True, inferSchema=True)
    time_df = spark.read.csv('./dimension_table/time_dimension.csv', header=True, inferSchema=True)
    college_dim_df = spark.read.csv('./dimension_table/college_dimension.csv', header=True, inferSchema=True)
    company_dim_df = spark.read.csv('./dimension_table/company_dimension.csv', header=True, inferSchema=True)
    survey_dim_df = spark.read.csv('./dimension_table/survey_dimension.csv', header=True, inferSchema=True)

    return company_source_df, college_source_df, time_df, college_dim_df, company_dim_df, survey_dim_df


# Prepare data by converting date columns and normalizing text fields
def prepare_data(company_source_df, college_source_df, time_df, college_dim_df, company_dim_df, survey_dim_df):
    # Ensure Date columns are in 'DateType' format
    company_source_df = company_source_df.withColumn("Date", to_date(col("Date"), "dd-MM-yyyy"))
    college_source_df = college_source_df.withColumn("Date", to_date(col("Date"), "dd-MM-yyyy"))
    time_df = time_df.withColumn("Date", to_date(col("Date"), "dd-MM-yyyy"))

    # Apply lower() and trim() for consistency in Company and College data
    company_source_df = company_source_df.withColumn("College_Name", lower(trim(col("College_Name")))) \
        .withColumn("Company_Name", lower(trim(col("Company_Name"))))

    college_dim_df = college_dim_df.withColumn("College_Name", lower(trim(col("College_Name"))))
    company_dim_df = company_dim_df.withColumn("Company_Name", lower(trim(col("Company_Name"))))

    # Apply lower() and trim() for College and Survey names in both the source and dimension tables
    college_source_df = college_source_df.withColumn("College", lower(trim(col("College")))) \
        .withColumn("SURVEY_Name", lower(trim(col("SURVEY_Name"))))

    survey_dim_df = survey_dim_df.withColumn("SURVEY_Name", lower(trim(col("SURVEY_Name"))))

    return company_source_df, college_source_df, time_df, college_dim_df, company_dim_df, survey_dim_df


# Create Fact College Details Table
def create_fact_college(company_source_df, time_df, college_dim_df, company_dim_df):
    # Join with Time Dimension to get Time_ID
    fact_college_df = company_source_df.join(time_df, company_source_df["Date"] == time_df["Date"], "inner") \
        .select(company_source_df["*"], time_df["Time_ID"])

    # Join with College Dimension to get College_ID (based on College_Name)
    fact_college_df = fact_college_df.join(college_dim_df,
                                           fact_college_df["College_Name"] == college_dim_df["College_Name"], "inner") \
        .select(fact_college_df["*"], college_dim_df["College_ID"])

    # Join with Company Dimension to get Company_ID (based on Company_Name)
    fact_college_df = fact_college_df.join(company_dim_df,
                                           fact_college_df["Company_Name"] == company_dim_df["Company_Name"], "inner") \
        .select(fact_college_df["*"], company_dim_df["Company_ID"])

    # Generate Fact ID using row_number()
    fact_college_df = fact_college_df.withColumn("Fact_ID", row_number().over(Window.orderBy("Date")))

    # Select final columns for Fact College Table
    fact_college_df = fact_college_df.select(
        "Fact_ID",
        "Time_ID",
        "College_ID",
        "Company_ID",
        col("Package").alias("Package_In_Lakhs"),
        "Student_Selected",
        "Student_Participated",
        "Criteria"
    )

    return fact_college_df


# Create Fact Survey Details Table
def create_fact_survey(college_source_df, time_df, college_dim_df, survey_dim_df):
    # Join with Time Dimension to get Time_ID
    fact_survey_df = college_source_df.join(time_df, college_source_df["Date"] == time_df["Date"], "inner") \
        .select(college_source_df["*"], time_df["Time_ID"])

    # Join with College Dimension to get College_ID (based on College)
    fact_survey_df = fact_survey_df.join(college_dim_df, fact_survey_df["College"] == college_dim_df["College_Name"],
                                         "inner") \
        .select(fact_survey_df["*"], college_dim_df["College_ID"])

    # Join with Survey Dimension to get Survey_ID (based on SURVEY_Name)
    fact_survey_df = fact_survey_df.join(survey_dim_df, fact_survey_df["SURVEY_Name"] == survey_dim_df["SURVEY_Name"],
                                         "inner") \
        .select(fact_survey_df["*"], survey_dim_df["Survey_ID"])

    # Select final columns for Fact Survey Table
    fact_survey_df = fact_survey_df.select(
        row_number().over(Window.orderBy("College")) \
            .alias("Fact_ID"),
        "Time_ID",
        "College_ID",
        "Survey_ID",
        col("NO_OF_STUDENTS_INDIAN").alias("Number_of_Indian_Students"),
        col("NO_OF_STUDENTS_FOREIGN").alias("Number_of_Foreign_Students"),
        "FEES",
        "RANK"
    )

    return fact_survey_df


# Main execution
def main():
    company_source_df, college_source_df, time_df, college_dim_df, company_dim_df, survey_dim_df = load_data()
    company_source_df, college_source_df, time_df, college_dim_df, company_dim_df, survey_dim_df = prepare_data(
        company_source_df, college_source_df, time_df, college_dim_df, company_dim_df, survey_dim_df)

    # Create Fact College Details Table
    fact_college_df = create_fact_college(company_source_df, time_df, college_dim_df, company_dim_df)
    print("Fact College Details:")
    fact_college_df.show(truncate=False)

    # Create Fact Survey Details Table
    fact_survey_df = create_fact_survey(college_source_df, time_df, college_dim_df, survey_dim_df)
    print("Fact Survey Details:")
    fact_survey_df.show(truncate=False)

    #Create fact_table directory if it doesn't exist
    output_dir = "fact_table"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Save the fact tables to CSV files in the fact_table directory
    fact_college_df.toPandas().to_csv(f"{output_dir}/fact_college_details.csv", index=False)
    fact_survey_df.toPandas().to_csv(f"{output_dir}/fact_survey_details.csv", index=False)


# Run the main function
if __name__ == "__main__":
    main()

# Stop the Spark session
spark.stop()
